package com.shareexpense.shareexpense;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShareexpenseApplication {

	public static void main(String[] args) {
		SpringApplication.run(ShareexpenseApplication.class, args);
	}

}
